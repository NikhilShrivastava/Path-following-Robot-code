# OMNIBot
An extremely budget DIY robot using Arduino UNO which uses minimal code.
Project was initially started by a group of 3 people, namely Satyam Kumar, Prasanjeet Keshri and Nikhil Shrivastava as a simple project for science exhibition in school, but, just before the exhibition day, it is now open source and licensed under GNU GPL v3.0.
